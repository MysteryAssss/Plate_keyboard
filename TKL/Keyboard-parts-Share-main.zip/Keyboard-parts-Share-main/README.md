LZ Keyboard Reference Project
1. Share the Parts draw
